#!/usr/bin/env bash

# Patch for group messages error https://github.com/tgalal/yowsup/pull/1364
# sed -i '106s/:/ and not "-" in node["to"]:/' /venv/local/lib/python2.7/site-packages/yowsup/layers/axolotl/layer.py
# no patches
